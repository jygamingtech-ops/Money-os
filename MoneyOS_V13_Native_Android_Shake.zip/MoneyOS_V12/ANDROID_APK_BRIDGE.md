# MoneyOS Android APK bridge

The web app is now bridge-ready.

The WebView wrapper can expose:
`window.AndroidMoneyOS.startShake()`
`window.AndroidMoneyOS.stopShake()`

When these methods exist, MoneyOS calls them when Shake to Quick Add is enabled/disabled.

## What the native wrapper must do

1. Register an Android accelerometer/linear-acceleration sensor listener.
2. Keep the listener alive according to Android background-execution rules.
3. When a real shake threshold is detected, bring/route the app UI to the MoneyOS WebView.
4. Trigger the Quick Add action in the WebView.
5. Ask for any required Android sensor/notification permissions using the normal Android permission flow.

A plain website cannot guarantee an always-on background sensor while fully closed. A native Android service/foreground mechanism is required for that behavior, subject to Android version and battery restrictions.

Do not paste private Supabase keys into this project yet.

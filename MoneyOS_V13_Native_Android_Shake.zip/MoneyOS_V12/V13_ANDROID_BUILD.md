# MoneyOS V13 — Android native shake starter

This version includes an Android Studio project under `android-app/`.

It packages the current web UI into an offline WebView and exposes:
`window.AndroidMoneyOS.startShake()`
`window.AndroidMoneyOS.stopShake()`

When Shake to Quick Add is enabled, the web layer calls the native bridge. The native service uses the Android accelerometer and triggers the Quick Add sheet.

## Build

Open the `android-app` folder in Android Studio, let Gradle sync, then build an APK.

## Important Android behavior

This is a real native implementation, but Android background execution rules vary by version/device. The foreground service displays a persistent system notification while shake monitoring is active. Users must allow required permissions.

The service does not guarantee detection after a forced-stop action, manufacturer battery-killer settings, or device shutdown/reboot.

No Supabase credentials are included.

package com.moneyos.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    public static MainActivity instance;
    WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        instance=this;
        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidMoneyOS");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},41);
    }

    public void startShakeService(){
        Intent i=new Intent(this, ShakeService.class);
        if(Build.VERSION.SDK_INT>=26) ContextCompat.startForegroundService(this,i); else startService(i);
    }
    public void stopShakeService(){ stopService(new Intent(this,ShakeService.class)); }

    public void quickAdd(){
        runOnUiThread(()->web.evaluateJavascript("if(typeof quickAdd==='function'){quickAdd();}",null));
    }

    class Bridge {
        @JavascriptInterface public void startShake(){ startShakeService(); }
        @JavascriptInterface public void stopShake(){ stopShakeService(); }
    }
}
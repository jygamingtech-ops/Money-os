package com.moneyos.app;

import android.app.*;
import android.content.*;
import android.hardware.*;
import android.os.*;
import androidx.core.app.NotificationCompat;

public class ShakeService extends Service implements SensorEventListener {
    SensorManager sm; Sensor sensor; float last=0; long lastHit=0;
    @Override public void onCreate(){
        super.onCreate();
        String ch="moneyos_shake";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"MoneyOS Shake",NotificationManager.IMPORTANCE_LOW));
        Notification n=new NotificationCompat.Builder(this,ch).setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("MoneyOS").setContentText("Shake Quick Add is active").setOngoing(true).build();
        startForeground(1301,n);
        sm=(SensorManager)getSystemService(SENSOR_SERVICE);
        sensor=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(sensor!=null) sm.registerListener(this,sensor,SensorManager.SENSOR_DELAY_GAME);
    }
    @Override public void onSensorChanged(SensorEvent e){
        float x=e.values[0],y=e.values[1],z=e.values[2];
        float mag=(float)Math.sqrt(x*x+y*y+z*z);
        float delta=Math.abs(mag-last); last=mag;
        long now=System.currentTimeMillis();
        if(delta>7 && now-lastHit>700){ lastHit=now; if(MainActivity.instance!=null) MainActivity.instance.quickAdd(); }
    }
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){if(sm!=null)sm.unregisterListener(this);super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
MoneyOS V13 — Native Android Shake Starter

Includes:
- Existing clean MoneyOS web app
- Android Studio wrapper project
- Offline WebView assets
- Native Android accelerometer service
- Foreground service notification
- JavaScript bridge for start/stop shake
- Native trigger opens MoneyOS Quick Add

Build the android-app folder with Android Studio to produce an APK.

Background shake is now implemented through Android-native code rather than pretending a web page can do it alone.
